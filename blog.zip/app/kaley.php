<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class kaley extends Model
{
    //
}
